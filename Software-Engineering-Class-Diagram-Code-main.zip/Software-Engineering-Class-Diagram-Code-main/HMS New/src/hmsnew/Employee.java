package hmsnew;

public class Employee extends Person {

	private String ID;
	private String Username;
	private String Password;

	public Employee() {
		// TODO - implement Employee.Employee
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Username
	 * @param Password
	 */
	public Employee(String Username, String Password) {
		// TODO - implement Employee.Employee
		throw new UnsupportedOperationException();
	}

}