/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hmsnew;

/**
 *
 * @author hp
 */
public class Secretary extends Employee {

	public void CheckDoctorAvailibility() {
		// TODO - implement Secretary.CheckDoctorAvailibility
		throw new UnsupportedOperationException();
	}

	public void BookDoctor() {
		// TODO - implement Secretary.BookDoctor
		throw new UnsupportedOperationException();
	}

	public void MaintainPatientDetails() {
		// TODO - implement Secretary.MaintainPatientDetails
		throw new UnsupportedOperationException();
	}

	public void EnrollPatientDetails() {
		// TODO - implement Secretary.EnrollPatientDetails
		throw new UnsupportedOperationException();
	}

	public void CheckDoctorSchedule() {
		// TODO - implement Secretary.CheckDoctorSchedule
		throw new UnsupportedOperationException();
	}

	public Secretary() {
		// TODO - implement Secretary.Secretary
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param name
	 */
	public Secretary(String name) {
		// TODO - implement Secretary.Secretary
		throw new UnsupportedOperationException();
	}

	public void GenerateBill() {
		// TODO - implement Secretary.GenerateBill
		throw new UnsupportedOperationException();
	}
   
}
