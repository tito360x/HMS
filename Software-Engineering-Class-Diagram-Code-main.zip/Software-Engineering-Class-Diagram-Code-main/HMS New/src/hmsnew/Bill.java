package hmsnew;

public class Bill {

	private String BillNo;
	private String PatientName;
	private int Price;

	public Bill() {
		// TODO - implement Bill.Bill
		throw new UnsupportedOperationException();
	}

	public String getBillNo() {
		// TODO - implement Bill.getBillNo
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param BillNo
	 */
	public void setBillNo(String BillNo) {
		// TODO - implement Bill.setBillNo
		throw new UnsupportedOperationException();
	}

	public String getPatientName() {
		// TODO - implement Bill.getPatientName
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param PatientName
	 */
	public void setPatientName(String PatientName) {
		// TODO - implement Bill.setPatientName
		throw new UnsupportedOperationException();
	}

	public int getPrice() {
		// TODO - implement Bill.getPrice
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Price
	 */
	public void setPrice(int Price) {
		// TODO - implement Bill.setPrice
		throw new UnsupportedOperationException();
	}

}